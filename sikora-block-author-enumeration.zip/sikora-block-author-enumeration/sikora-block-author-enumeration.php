<?php
/**
 * Plugin Name: Sikora Block Author Enumeration (Security)
 * Description: Prevents author enumeration attacks by redirecting front-end requests that carry an ?author= query parameter to the homepage. This closes a common WordPress security vulnerability that allows bots and attackers to discover valid usernames.
 * Version: 1.0.1
 * Author: <a href="https://SikoraCollective.com/">Sikora Collective</a>
 */

// Exit if accessed directly — prevents direct file execution outside WordPress.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Blocks author enumeration attempts via the ?author= query parameter.
 *
 * WordPress exposes usernames through URLs like /?author=1, /?author=2, etc.
 * Attackers exploit this to enumerate valid user accounts before attempting
 * brute-force login attacks. This function intercepts those requests on the
 * front end and issues a 301 redirect to the site homepage, revealing nothing
 * about existing users.
 *
 * Any request carrying an `author` parameter is redirected, regardless of its
 * value. WordPress casts the value with intval(), so variants such as
 * ?author=1a, ?author=1,2 and ?author[]=1 all resolve to a user ID; checking
 * only for purely numeric values would let those through. Legitimate author
 * archives use pretty permalinks (/author/slug/) and are unaffected.
 *
 * Hooked to 'template_redirect' at priority 1 so it runs before WordPress's
 * own redirect_canonical() (priority 10), which is what performs the
 * username-revealing redirect. This hook only fires for front-end page loads,
 * so the admin area, admin-ajax, cron and REST API requests (which the block
 * editor uses with ?author= to filter posts) are unaffected.
 *
 * @return void
 */
function sikora_block_author_enumeration() {
	// Only presence matters; the value is never read or output.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
	if ( isset( $_GET['author'] ) || isset( $_POST['author'] ) ) {
		// Redirect to the homepage with a permanent (301) status code.
		// wp_safe_redirect() restricts the target to the site's own host.
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'sikora_block_author_enumeration', 1 );
